public class Player extends Entity {

    public Player() {
        super(0, 0);
    }

    public boolean move(char direction, Map map) {
        int newX = x;
        int newY = y;

        // decided to use switch since in general its more elegant than 4 else if's
        // change movement node depending on the user input
        switch (Character.toUpperCase(direction)) {
            case 'W' -> newY++;
            case 'S' -> newY--;
            case 'A' -> newX--;
            case 'D' -> newX++;
            default -> {
                return false;
            }
        }

        // enforce movement rules
        if (!map.isWall(newX, newY)) {
            this.x = newX;
            this.y = newY;

            // collect the treasure if it is encountered
            if (map.hasTreasure(x, y)) {
                map.removeTreasure(x, y);
            }
            return true;
        } else {
            System.out.println("You hit a wall!");
            return false;
        }
    }
}