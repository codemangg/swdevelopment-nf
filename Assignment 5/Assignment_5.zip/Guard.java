import java.util.Random;

public class Guard extends Entity {

    Random random;

    public Guard(int x, int y) {
        super(x, y);
        this.random = new Random();
    }

    public boolean move(char direction, Map map) {

        // try 20 times if a valid move can be found since the guard cant repeat its
        // input
        // I am quite confident that 20 iterations should be enough to find a valid move
        // (in theory 4 are enough since there are
        // 4 directions but the random factor is always a risk)
        for (int i = 0; i < 20; i++) {
            int newX = x;
            int newY = y;

            int randomDirection = random.nextInt(4);

            // decided to use switch since in general its more elegant than 4 else if's
            // change movement with a random factor and moves accordingly
            switch (randomDirection) {
                case 0 -> newY++;
                case 1 -> newY--;
                case 2 -> newX--;
                case 3 -> newX++;
            }

            // enforce movement rules
            if (!map.isWall(newX, newY)) {
                this.x = newX;
                this.y = newY;
                break;
            }
        }
        return true;
    }
}