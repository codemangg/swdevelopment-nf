import java.util.Random;

public class Map {

    char[][] grid;
    int size;
    int treasureCount;

    char EMPTY = ' ';
    char WALL = '|';
    char TREASURE = '€';

    public Map(int size, double wallProbability) {
        this.size = size;
        this.grid = new char[size][size];
        this.treasureCount = 0;

        initializeMap(wallProbability);
    }

    public void initializeMap(double wallProbability) {
        Random rand = new Random();
        int maxTreasures = 4;

        // iterate over the whole grid
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {

                grid[x][y] = EMPTY;

                if (x == 0 && y == 0)
                    continue;

                double chance = rand.nextDouble();

                // first decide if this tile becomes a wall
                if (chance < wallProbability) {
                    grid[x][y] = WALL;

                    // otherwise, with a smaller probability, place a treasure
                } else if (treasureCount < maxTreasures && rand.nextDouble() < 0.15) {
                    grid[x][y] = TREASURE;
                    treasureCount++;
                }
            }
        }
    }

    public boolean isWall(int x, int y) {

        // create walls and make sure grid borders are respected
        if (x < 0 || x >= size || y < 0 || y >= size) {
            return true;
        }

        return grid[x][y] == WALL;
    }

    public boolean hasTreasure(int x, int y) {

        // treasures can not be outside of the grid
        if (x < 0 || x >= size || y < 0 || y >= size)
            return false;

        return grid[x][y] == TREASURE;
    }

    public void removeTreasure(int x, int y) {

        // only remove if there actually is a treasure
        if (hasTreasure(x, y)) {
            grid[x][y] = EMPTY;
            treasureCount--;

            System.out.println(
                    "You found a treasure! there are only "
                            + treasureCount + " treasures remaining.");
        }
    }

    public boolean isWin() {
        return treasureCount == 0;
    }

    public int getSize() {
        return size;
    }
}