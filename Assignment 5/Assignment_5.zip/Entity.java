public abstract class Entity {

    int x;
    int y;

    public Entity(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract boolean move(char direction, Map map);

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}