import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int mazeSize = 8;
        Map map = null;
        boolean difficultySelected = false;

        while (!difficultySelected) {
            System.out.println("Please choose a difficulty (EASY, MEDIUM, HARD, IMPOSSIBLE) or QUIT to exit: ");
            String input = scanner.nextLine().toUpperCase();

            if (input.isEmpty())
                continue;
            char diff = input.charAt(0);

            // As before, I was a bit motivated and couldnt decide for a wall probability so
            // I let the player decice :D
            // set difficulty (wall spawn probability) depending on the user input
            // if the input is Q, set playing mode to false and escape the loop as while
            // checks playing condition
            switch (diff) {
                case 'E' -> {
                    map = new Map(mazeSize, 0.10);
                    difficultySelected = true;
                }
                case 'M' -> {
                    map = new Map(mazeSize, 0.20);
                    difficultySelected = true;
                }
                case 'H' -> {
                    map = new Map(mazeSize, 0.30);
                    difficultySelected = true;
                }
                case 'I' -> {
                    map = new Map(mazeSize, 0.50);
                    difficultySelected = true;
                }
                case 'Q' -> {
                    System.out.println("Thanks for NOT playing :(");
                    scanner.close(); // as in this assignment, there is more code inbetween, I think its more elegant
                                     // to close the scanner rahter than setting the playing flag
                    return;
                }
            }
        }

        // create entity list as required
        List<Entity> entities = new ArrayList<>();
        Player player = new Player();
        entities.add(player);

        // guard spawns at any location but 0:0 and a wall
        Random rand = new Random();
        int gX, gY;
        do {
            gX = rand.nextInt(mazeSize);
            gY = rand.nextInt(mazeSize);
        } while (map.isWall(gX, gY) || (gX == 0 && gY == 0));

        Guard guard = new Guard(gX, gY);
        entities.add(guard);

        boolean playing = true;
        while (playing) {

            // print as defined in the example given
            System.out.println("Player position: " + player.toString());
            System.out.println("Guard position: " + guard.toString());
            System.out.println("Move with W/A/S/D or quit with Q: ");

            String input = scanner.nextLine().toUpperCase();
            if (input.isEmpty())
                continue;

            if (input.equals("Q")) {
                playing = false;
                break;
            }
            char moveChar = input.charAt(0);

            for (Entity e : entities) {
                boolean moveSuccessful = e.move(moveChar, map);

                // only move the guard if player does NOT hit a wall
                if (e instanceof Player && !moveSuccessful) {
                    break;
                }
            }

            // player wins if all treasures were found
            // break loop because otherwise there is a possibility to have win/lose if all
            // treasures are found at the exact same point where player and guard meet
            if (map.isWin()) {
                System.out.println("YOU WON! All treasures collected.");
                playing = false;
                break;
            }

            // player loses if they get in contact with the guard
            if (player.getX() == guard.getX() && player.getY() == guard.getY()) {
                System.out.println("Player position: " + player.toString());
                System.out.println("Guard position: " + guard.toString());
                System.out.println("You lost because you were caught by the guard :(");
                playing = false;
                break;
            }
        }

        scanner.close();
    }
}