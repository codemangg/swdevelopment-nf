import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int mazeSize = 8;
        int energy = 15;

        Player player = new Player(energy);
        Maze maze = null;

        boolean playing = true;
        boolean difficultySelected = false;

        while (!difficultySelected) {
            System.out.println("Please choose a difficulty (EASY, MEDIUM, HARD, IMPOSSIBLE) or QUIT to exit: ");
            String input = scanner.nextLine().toUpperCase();

            if (input.isEmpty()) continue;
            char difficulty = input.charAt(0);

            // I was a bit motivated and couldnt decide for a wall probability so I let the player decice :D
            // set difficulty (wall spawn probability) depending on the user input
            // if the input is Q, set playing mode to false and escape the loop as while checks playing condition
            switch (difficulty) {
                case 'E' -> {
                    maze = new Maze(mazeSize, 0.10);
                    difficultySelected = true;
                }
                case 'M' -> {
                    maze = new Maze(mazeSize, 0.20);
                    difficultySelected = true;
                }
                case 'H' -> {
                    maze = new Maze(mazeSize, 0.30);
                    difficultySelected = true;
                }
                case 'I' -> {
                    maze = new Maze(mazeSize, 0.50);
                    difficultySelected = true;
                }
                case 'Q' -> {
                    playing = false;
                    difficultySelected = true;
                    System.out.println("Thanks for NOT playing :(");
                }
                default -> {
                }
            }
        }

        while (playing) {

            // print as defined in the example given
            System.out.println("Current position: (" + player.getX() + ", " + player.getY() + ")");
            System.out.println("Current energy: " + player.getEnergy());
            System.out.println("Move with W/A/S/D or quit with Q: ");

            String input = scanner.nextLine().toUpperCase();
            if (input.isEmpty()) continue;

            int x = player.getX();
            int y = player.getY();

            char move = input.charAt(0);

            // decided to use switch since in general its more elegant than 4 else if's
            // change movement node depending on the user input
            // if the input is Q, set playing mode to false and escape the loop as while checks playing condition
            switch (move) {
                case 'W' -> { y++; }
                case 'S' -> { y--; }
                case 'A' -> { x--; }
                case 'D' -> { x++; }
                case 'Q' -> {
                    playing = false;
                    System.out.println("Thanks for NOT playing :(");
                }
                default -> {
                    continue;
                }
            }

            // check if target location is inside the grid and invalidate move if it is not
            if (x < 0 || x >= maze.getSize() || y < 0 || y >= maze.getSize()) {
                System.out.println("Invalid move, stay inside the grid ;)");
                continue;
            }

            Tile nextTile = maze.getTile(x, y);

            // check if the target location is a wall and invalidate move if it is
            if (nextTile.isWall()) {
                System.out.println("You hit a wall, choose a different direction!");
                continue;
            }

            // actually move the player user input before -> detected string breaks the switch and continues the loop
            switch (move) {
                case 'W' -> { player.moveUp(); }
                case 'S' -> { player.moveDown(); }
                case 'A' -> { player.moveLeft(); }
                case 'D' -> { player.moveRight(); }
                default -> {
                    continue;
                }
            }

            player.useEnergy();

            // if player finds the exit, exit the loop and finish
            if (nextTile.isExit()) {
                System.out.println("You escaped the maze, thanks for playing!");
                break;
            }

            // if player drops to 0 hp, exit the loop and finish
            if (player.getEnergy() == 0) {
                System.out.println("You have no energy left, game over :(, but thanks for playing :D!");
                break;
            }
        }
        scanner.close();
    }
}
