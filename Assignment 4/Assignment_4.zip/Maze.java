import java.util.Random;

public class Maze {

    Tile[][] grid;
    int size;
    
    public Tile getTile(int x, int y) {
        return grid[x][y];
    }

    public int getSize() {
        return size;
    }

    public Maze(int size, double wallProbability) {
        this.size = size;
        this.grid = new Tile[size][size];

        Random rand = new Random();

        // fill the grid wit tiles
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                grid[x][y] = new Tile(false, false);
            }
        }

        // create exit point
        int exitIdx = rand.nextInt(size * size - 1) + 1;
        int exitX = exitIdx % size;
        int exitY = exitIdx / size;

        grid[exitX][exitY] = new Tile(false, true);

        // create walls with the specified probability
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                if ((x == 0 && y == 0) || grid[x][y].isExit()) {
                    continue;
                }

                if (rand.nextDouble() < wallProbability) {
                    grid[x][y] = new Tile(true, false);
                }
            }
        }
    }
}
