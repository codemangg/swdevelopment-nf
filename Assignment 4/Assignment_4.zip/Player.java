public class Player {

    int x;
    int y;
    int energy;

    public Player(int energy) {
        this.x = 0;
        this.y = 0; 
        this.energy = energy;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getEnergy() {
        return energy;
    }

    public void moveUp() {
        y++;
    }

    public void moveDown() {
        y--;
    }

    public void moveLeft() {
        x--;
    }

    public void moveRight() {
        x++;
    }

    public void useEnergy() {
        energy--;
    }

}